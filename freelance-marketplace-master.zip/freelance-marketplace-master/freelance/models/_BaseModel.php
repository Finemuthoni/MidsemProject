<?php

namespace app\models;

use app\Database;

abstract class _BaseModel extends Database
{
}