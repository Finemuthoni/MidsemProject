<!----------------------------- header -------------------------------------------------------->

<div class="container" style="margin-top:50px;">
    <h1 style="text-align:center; margin-bottom:50px;">Admin</h1>

    <div>
        <h3>Users</h3>
        <p><a href="/admin/users">Users home &rarr; </a></p>
    </div>
    <div>
        <h3>Freelancers</h3>
        <p><a href="/admin/freelancers">Freelancers home &rarr; </a></p>
    </div>
    <div>
        <h3>Clients</h3>
        <p><a href="/admin/clients">Clients home &rarr; </a></p>
    </div>
    <div>
        <h3>Jobs</h3>
        <p><a href="/admin/jobs">Jobs home &rarr; </a></p>
    </div>
    <div>
        <h3>Other</h3>
        <p><a href="/admin/skills">Skills home &rarr; </a></p>
        <p><a href="/admin/skills/create">Create skill &rarr; </a></p>
    </div>
</div>
<hr />
<!----------------------------- end header -------------------------------------------------------->