<?php

echo "Admin proposals";
