<!----------------------------- header -------------------------------------------------------->

<div class="container" style="margin-top:50px;">
    <h1 style="text-align:center; margin-bottom:50px;">Proposals</h1>
</div>
<hr />
<!----------------------------- end header -------------------------------------------------------->