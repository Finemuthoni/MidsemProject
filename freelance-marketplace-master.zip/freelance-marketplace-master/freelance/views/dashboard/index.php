<!----------------------------- header -------------------------------------------------------->

<div class="container" style="margin-top:50px;">
    <h1 style="text-align:center; margin-bottom:50px;">Your dashboard</h1>
    <div class="row">
        <div class="column" style="margin-top:40px;">
            <h2>Freelancer</h2>
            <a href="/dashboard/freelancer">Freelancer home &rarr; </a>
            <hr style="margin: 1rem 0;" />
        </div>
        <div class="column" style="margin-top:40px;">
            <h2>Client</h2>
            <a href="/dashboard/client">Client home &rarr; </a>
            <hr style="margin: 1rem 0;" />
        </div>
    </div>
</div>
<hr />
<!----------------------------- end header -------------------------------------------------------->