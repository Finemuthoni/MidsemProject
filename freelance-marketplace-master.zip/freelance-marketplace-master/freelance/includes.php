<?php

date_default_timezone_set("Africa/Nairobi");
